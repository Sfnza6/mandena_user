import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:get/get.dart' hide FormData;
import 'package:mandena/modules/branch/branch_controller.dart';
import 'env.dart';

class ApiService {
  ApiService()
    : _dio =
          Dio(
              BaseOptions(
                baseUrl: _fixBaseUrl(Env.baseUrl),
                connectTimeout: const Duration(seconds: 20),
                receiveTimeout: const Duration(seconds: 20),
                headers: const {
                  'Accept': 'application/json',
                  'Cache-Control':
                      'no-store, no-cache, must-revalidate, max-age=0',
                  'Pragma': 'no-cache',
                },
              ),
            )
            ..interceptors.add(
              LogInterceptor(requestBody: true, responseBody: true),
            );

  final Dio _dio;

  static String _fixBaseUrl(String s) => s.endsWith('/') ? s : '$s/';
  static String _norm(String path) =>
      (path.startsWith('http://') || path.startsWith('https://'))
      ? path
      : (path.startsWith('/') ? path : '/$path');

  Future<void> _checkConnection() async {
    final result = await Connectivity().checkConnectivity();
    if (result == ConnectivityResult.none) {
      throw Exception('لا يوجد اتصال بالإنترنت');
    }
  }

  int _branchId() {
    try {
      if (Get.isRegistered<BranchController>()) {
        return Get.find<BranchController>().selectedBranchId.value;
      }
    } catch (_) {}
    return 0;
  }

  Map<String, dynamic> _injectBranchToParams(Map<String, dynamic>? params) {
    final branchId = _branchId();
    return {
      if (params != null) ...params,
      if (branchId > 0) 'branch_id': '$branchId',
    };
  }

  Map<String, dynamic> _injectBranchToBody(Map<String, dynamic>? body) {
    final branchId = _branchId();
    return {
      if (body != null) ...body,
      if (branchId > 0) 'branch_id': '$branchId',
    };
  }

  Map<String, dynamic> _branchHeaders([Map<String, dynamic>? headers]) {
    final branchId = _branchId();
    return {
      if (headers != null) ...headers,
      if (branchId > 0) 'X-Branch-Id': '$branchId',
    };
  }

  Future<dynamic> get(String path, {Map<String, String>? params}) async {
    await _checkConnection();
    try {
      final qp = _injectBranchToParams({
        if (params != null) ...params,
        '_ts': DateTime.now().millisecondsSinceEpoch.toString(),
      });

      final r = await _dio.get(
        _norm(path),
        queryParameters: qp,
        options: Options(
          headers: _branchHeaders(const {
            'Cache-Control': 'no-store, no-cache, must-revalidate, max-age=0',
            'Pragma': 'no-cache',
          }),
        ),
      );
      if (kDebugMode) {
        debugPrint('[GET] ${r.requestOptions.uri} -> ${r.statusCode}');
      }
      return r.data;
    } on DioException catch (e) {
      final res = e.response?.data;
      final msg = (res is Map && res['message'] != null)
          ? res['message'].toString()
          : e.message ?? 'NETWORK_ERROR';
      throw Exception(msg);
    }
  }

  Future<dynamic> post(String path, {Map<String, dynamic>? body}) async {
    await _checkConnection();
    try {
      final requestBody = _injectBranchToBody(body);

      final r = await _dio.post(
        _norm(path),
        data: requestBody,
        options: Options(
          contentType: Headers.formUrlEncodedContentType,
          headers: _branchHeaders(const {
            'Cache-Control': 'no-store, no-cache, must-revalidate, max-age=0',
            'Pragma': 'no-cache',
          }),
        ),
      );
      if (kDebugMode) {
        debugPrint('[POST] ${r.requestOptions.uri} -> ${r.statusCode}');
      }
      return r.data;
    } on DioException catch (e) {
      final res = e.response?.data;
      final msg = (res is Map && res['message'] != null)
          ? res['message'].toString()
          : e.message ?? 'NETWORK_ERROR';
      throw Exception(msg);
    }
  }

  Future<Map<String, dynamic>> postForm(
    String path,
    Map<String, dynamic> data,
  ) async {
    await _checkConnection();
    try {
      final payload = _injectBranchToBody(data);

      final r = await _dio.post(
        _norm(path),
        data: FormData.fromMap(payload),
        options: Options(
          headers: _branchHeaders(const {
            'Cache-Control': 'no-store, no-cache, must-revalidate, max-age=0',
            'Pragma': 'no-cache',
          }),
        ),
      );
      if (r.data is Map) {
        return Map<String, dynamic>.from(r.data as Map);
      }
      throw Exception('INVALID_RESPONSE');
    } on DioException catch (e) {
      final res = e.response?.data;
      final msg = (res is Map && res['message'] != null)
          ? res['message'].toString()
          : e.message ?? 'NETWORK_ERROR';
      throw Exception(msg);
    }
  }

  Future<Map<String, dynamic>> postJson(
    String path,
    Map<String, Object?> data,
  ) async {
    await _checkConnection();
    try {
      final payload = _injectBranchToBody(Map<String, dynamic>.from(data));

      final r = await _dio.post(
        _norm(path),
        data: payload,
        options: Options(
          headers: _branchHeaders(const {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Cache-Control': 'no-store, no-cache, must-revalidate, max-age=0',
            'Pragma': 'no-cache',
          }),
        ),
      );

      if (kDebugMode) {
        debugPrint('[POST JSON] ${r.requestOptions.uri} -> ${r.statusCode}');
        debugPrint('[POST JSON] body = $payload');
        debugPrint('[POST JSON] response = ${r.data}');
      }

      if (r.data is Map) {
        return Map<String, dynamic>.from(r.data as Map);
      }
      throw Exception('INVALID_RESPONSE');
    } on DioException catch (e) {
      final res = e.response?.data;
      final msg = (res is Map && res['message'] != null)
          ? res['message'].toString()
          : e.message ?? 'NETWORK_ERROR';
      throw Exception(msg);
    }
  }
}
