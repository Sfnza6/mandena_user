// lib/modules/categories/categories_view.dart
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../app_routes.dart';
import '../../home/home_controller.dart';
import '../../data/models/category.dart';
import '../../data/models/item.dart';

const _brown = Color(0xFF8A531C);
const _headerGold = Color(0xFFC9A15D);
const _goldText = Color(0xFFD1A34A);
const _pageBg = Color(0xFFF7F4EF);
const _softCard = Colors.white;
const _softIconBg = Color(0xFFF2EEE8);
const _border = Color(0xFFEDE3D6);

class CategoriesView extends StatefulWidget {
  const CategoriesView({super.key});

  @override
  State<CategoriesView> createState() => _CategoriesViewState();
}

class _CategoriesViewState extends State<CategoriesView> {
  static bool _cacheInitDone = false;
  static const _catsCacheKey = 'evoranta_cats_cache_v1';

  late HomeController c;
  final _searchCtrl = TextEditingController();
  final _searchQuery = ''.obs;
  final _selectedCatId = RxnInt();

  @override
  void initState() {
    super.initState();

    c = Get.isRegistered<HomeController>()
        ? Get.find<HomeController>()
        : Get.put(HomeController(), permanent: true);

    if (!_cacheInitDone) {
      _cacheInitDone = true;
      _initCache(c);
    }

    final args = Get.arguments;
    if (args is Map && args['categoryId'] != null) {
      final id = args['categoryId'];
      _selectedCatId.value = id is int ? id : int.tryParse('$id');
    }

    _searchCtrl.addListener(() {
      _searchQuery.value = _searchCtrl.text.trim();
    });
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  static Future<void> _initCache(HomeController c) async {
    try {
      final sp = await SharedPreferences.getInstance();
      final s = sp.getString(_catsCacheKey);
      if (s != null && s.isNotEmpty && c.categories.isEmpty) {
        final data = jsonDecode(s);
        if (data is List) {
          final list = data
              .map(
                (e) =>
                    CategoryModel.fromJson(Map<String, dynamic>.from(e as Map)),
              )
              .toList();
          c.categories.assignAll(list);
        }
      }
    } catch (_) {}

    ever<List<CategoryModel>>(c.categories, (list) async {
      try {
        final sp = await SharedPreferences.getInstance();
        final data = list
            .map(
              (cat) => {
                'id': cat.id,
                'name': cat.name,
                'image_url': cat.imageUrl,
              },
            )
            .toList();
        await sp.setString(_catsCacheKey, jsonEncode(data));
      } catch (_) {}
    });
  }

  List<ItemModel> _filteredItems() {
    final all = [...c.mostOrdered, ...c.topRated];

    final seen = <int>{};
    final unique = all.where((it) {
      if (seen.contains(it.id)) return false;
      seen.add(it.id);
      return true;
    }).toList();

    var result = unique;

    if (_selectedCatId.value != null) {
      result = result
          .where((it) => it.categoryId == _selectedCatId.value)
          .toList();
    }

    final q = _searchQuery.value.toLowerCase();
    if (q.isNotEmpty) {
      result = result.where((it) => it.name.toLowerCase().contains(q)).toList();
    }

    return result;
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: _pageBg,
        body: Obx(() {
          return Column(
            children: [
              _CategoriesHeader(searchCtrl: _searchCtrl),

              if (c.netError.value)
                _NetBanner(message: c.netMsg.value, onRetry: c.retry),

              Expanded(
                child: RefreshIndicator(
                  color: _brown,
                  onRefresh: () async => c.fetchCategories(),
                  child: _buildBody(),
                ),
              ),
            ],
          );
        }),
      ),
    );
  }

  Widget _buildBody() {
    if (c.loadingCats.value && c.categories.isEmpty) {
      return const Center(child: CircularProgressIndicator(color: _brown));
    }

    if (c.categories.isEmpty) {
      return _EmptyState(
        title: c.netError.value ? 'تعذّر جلب الأقسام' : 'لا توجد أقسام حالياً',
        message: c.netError.value
            ? '⚠️ قد يكون الاتصال بالإنترنت غير متاح.'
            : 'سيتم عرض الأقسام عند توفرها.',
        actionLabel: 'إعادة المحاولة',
        onAction: c.fetchCategories,
      );
    }

    final items = _filteredItems();
    final itemCount = items.length;

    return CustomScrollView(
      physics: const BouncingScrollPhysics(
        parent: AlwaysScrollableScrollPhysics(),
      ),
      slivers: [
        const SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.fromLTRB(16, 18, 16, 10),
            child: Align(
              alignment: Alignment.centerRight,
              child: Text(
                'جميع الأقسام',
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w900,
                  color: Color(0xFF1F160F),
                ),
              ),
            ),
          ),
        ),

        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          sliver: Obx(() {
            return SliverGrid(
              delegate: SliverChildBuilderDelegate((_, i) {
                final cat = c.categories[i];
                final isSelected = _selectedCatId.value == cat.id;

                return _CategoryCard(
                  cat: cat,
                  isSelected: isSelected,
                  onTap: () {
                    if (_selectedCatId.value == cat.id) {
                      _selectedCatId.value = null;
                    } else {
                      _selectedCatId.value = cat.id;
                    }
                  },
                );
              }, childCount: c.categories.length),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                mainAxisSpacing: 14,
                crossAxisSpacing: 14,
                childAspectRatio: 0.8,
              ),
            );
          }),
        ),

        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 10),
            child: Row(
              children: [
                Text(
                  '$itemCount صنف',
                  style: const TextStyle(
                    color: _goldText,
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                ),
                const Spacer(),
                const Text(
                  'جميع الأصناف',
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF1F160F),
                  ),
                ),
              ],
            ),
          ),
        ),

        if (items.isEmpty)
          const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.fromLTRB(24, 8, 24, 32),
              child: Center(
                child: Text(
                  'لا توجد أصناف في هذا القسم',
                  style: TextStyle(
                    color: Colors.black54,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          )
        else
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
            sliver: SliverGrid(
              delegate: SliverChildBuilderDelegate(
                (_, i) => _ItemCard(item: items[i]),
                childCount: items.length,
              ),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 0.78,
              ),
            ),
          ),
      ],
    );
  }
}

class _CategoriesHeader extends StatelessWidget {
  const _CategoriesHeader({required this.searchCtrl});

  final TextEditingController searchCtrl;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: _headerGold,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
      ),
      padding: EdgeInsets.fromLTRB(
        16,
        MediaQuery.of(context).padding.top + 12,
        16,
        18,
      ),
      child: Column(
        children: [
          const SizedBox(height: 2),
          const Row(
            children: [
              Spacer(),
              Text(
                'الأقسام',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Container(
            height: 42,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
            ),
            child: TextField(
              controller: searchCtrl,
              textAlign: TextAlign.right,
              decoration: const InputDecoration(
                hintText: 'ابحث في القائمة...',
                hintStyle: TextStyle(color: Colors.grey, fontSize: 13.5),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 11,
                ),
                prefixIcon: Icon(
                  Icons.search_rounded,
                  color: Colors.grey,
                  size: 20,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Align(
            alignment: Alignment.centerLeft,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(.16),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.white.withOpacity(.35)),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.tune_rounded, color: Colors.white, size: 18),
                  SizedBox(width: 6),
                  Text(
                    'تصفية',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _CategoryCard extends StatelessWidget {
  const _CategoryCard({
    required this.cat,
    required this.isSelected,
    required this.onTap,
  });

  final CategoryModel cat;
  final bool isSelected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final bg = isSelected ? const Color(0xFFF0E1C4) : _softCard;
    final borderColor = isSelected ? const Color(0xFFD8B57A) : _border;

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: borderColor),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.05),
              blurRadius: 12,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 58,
              height: 58,
              decoration: BoxDecoration(
                color: _softIconBg,
                borderRadius: BorderRadius.circular(14),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: Image.network(
                  cat.imageUrl,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const Icon(
                    Icons.fastfood_rounded,
                    color: _brown,
                    size: 28,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              cat.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: Color(0xFF2B2118),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ItemCard extends StatelessWidget {
  const _ItemCard({required this.item});

  final ItemModel item;

  bool get _hasDiscount =>
      (item.discount ?? '').toString().trim().isNotEmpty &&
      (item.discount ?? '').toString().trim() != '0';

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Get.toNamed(AppRoutes.itemDetail, arguments: item.toJson()),
      child: Container(
        decoration: BoxDecoration(
          color: _softCard,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.06),
              blurRadius: 12,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          children: [
            Expanded(
              child: Stack(
                children: [
                  Positioned.fill(
                    child: Image.network(
                      item.imageUrl,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        color: _softIconBg,
                        alignment: Alignment.center,
                        child: const Icon(
                          Icons.fastfood_rounded,
                          color: _brown,
                          size: 30,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 10,
                    left: 10,
                    child: Container(
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(.06),
                            blurRadius: 8,
                            offset: const Offset(0, 3),
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.favorite_border_rounded,
                        color: _brown,
                        size: 20,
                      ),
                    ),
                  ),
                  if (_hasDiscount)
                    Positioned(
                      top: 10,
                      right: 10,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFFB88A12),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Text(
                          'خصم %${item.discount}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w800,
                            fontSize: 11,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 10, 10, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    item.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.right,
                    style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 13.5,
                      color: Color(0xFF2B2118),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          color: _brown,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(
                          Icons.add,
                          color: Colors.white,
                          size: 18,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        'د.ل ${item.price.toStringAsFixed(0)}',
                        style: const TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 13,
                          color: _brown,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _NetBanner extends StatelessWidget {
  const _NetBanner({required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: const Color(0xFFFFF3CD),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: Row(
        children: [
          TextButton(onPressed: onRetry, child: const Text('إعادة المحاولة')),
          const Spacer(),
          Expanded(
            flex: 4,
            child: Text(
              message,
              textAlign: TextAlign.right,
              style: const TextStyle(
                color: Color(0xFF7A5A00),
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({
    required this.title,
    required this.message,
    required this.actionLabel,
    required this.onAction,
  });

  final String title;
  final String message;
  final String actionLabel;
  final Future<void> Function() onAction;

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        const SizedBox(height: 120),
        Center(
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 24),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: _softCard,
              borderRadius: BorderRadius.circular(18),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(.05),
                  blurRadius: 12,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: Column(
              children: [
                const Icon(Icons.inbox_rounded, size: 42, color: _brown),
                const SizedBox(height: 12),
                Text(
                  title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 16,
                    color: Color(0xFF2B2118),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.black54, height: 1.4),
                ),
                const SizedBox(height: 14),
                ElevatedButton(
                  onPressed: onAction,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _brown,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 12,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: Text(actionLabel),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
