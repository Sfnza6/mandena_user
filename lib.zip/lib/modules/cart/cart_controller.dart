import 'dart:convert'; // ← للكاش

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mandena/core/api_service.dart';
import 'package:mandena/core/session.dart';
import 'package:mandena/data/models/address.dart';
import 'package:mandena/modules/branch/branch_controller.dart';
import 'package:shared_preferences/shared_preferences.dart'; // ← للكاش

// === إضافة: موديل العنوان

class CartController extends GetxController {
  final _api = ApiService();

  // حالة
  final isBusy = false.obs;

  /// كل عنصر بالسلة:
  /// {
  ///   cart_item_id, item_id, name, price(double), quantity(int),
  ///   image_url, addons:[{id,name,price(double),qty(int),image_url}],
  ///   removals:[{id,name}], unit_total(double), short_desc(String),
  ///   line_total(double)
  /// }
  final cart = <Map<String, dynamic>>[].obs;

  // مجاميع
  final subtotal = 0.0.obs;
  final delivery = 0.0.obs;
  final services = 0.0.obs;

  double get total => subtotal.value + delivery.value + services.value;

  int? _userId;

  // === العنوان المختار في السلة (كائن + نص للعرض) ==================
  final selectedAddress = Rxn<Address>(); // موجود من قبل

  // === NEW: اسم العنوان الافتراضي لعرضه مباشرة في واجهة السلة
  final selectedAddressName = ''.obs;

  // ================================================================

  // ===================== رسائل ودّية + Snackbar أنيق ======================

  DateTime? _lastSnackAt;
  static const _snackThrottle = Duration(seconds: 4);

  void _showSnack({
    required Color bg,
    required String title,
    required String msg,
    String? actionLabel,
    VoidCallback? onAction,
    int seconds = 4,
  }) {
    final now = DateTime.now();
    if (_lastSnackAt != null &&
        now.difference(_lastSnackAt!) < _snackThrottle) {
      return;
    }
    _lastSnackAt = now;

    Get.rawSnackbar(
      borderRadius: 14,
      snackStyle: SnackStyle.FLOATING,
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      backgroundColor: bg,
      messageText: Directionality(
        textDirection: TextDirection.rtl,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
                fontSize: 15,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              msg,
              style: const TextStyle(
                color: Color(0xFFE5E7EB),
                fontSize: 13.5,
                height: 1.3,
              ),
            ),
          ],
        ),
      ),
      mainButton: TextButton(
        onPressed: () {
          Get.back();
          if (onAction != null) onAction();
        },
        child: Text(
          actionLabel ?? 'إغلاق',
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
      duration: Duration(seconds: seconds),
    );
  }

  void _showUserError(
    String msg, {
    String title = 'تعذّر إتمام العملية',
    VoidCallback? onRetry,
  }) {
    _showSnack(
      bg: const Color(0xFF1F2937),
      title: title,
      msg: msg,
      actionLabel: onRetry != null ? 'إعادة المحاولة' : 'إغلاق',
      onAction: onRetry,
    );
  }

  // ignore: unused_element
  void _showInfo(String msg, {String title = 'تنبيه'}) {
    _showSnack(bg: const Color(0xFF374151), title: title, msg: msg, seconds: 3);
  }

  // ignore: unused_element
  void _showSuccess(String msg, {String title = 'تم'}) {
    _showSnack(bg: const Color(0xFF065F46), title: title, msg: msg, seconds: 3);
  }

  String _friendlyMessage(Object e) {
    final t = e.toString().toLowerCase();
    if (t.contains('failed host lookup') ||
        t.contains('socketexception') ||
        t.contains('network is unreachable') ||
        t.contains('network_error') ||
        t.contains('no address associated with hostname') ||
        t.contains('لا يوجد اتصال')) {
      return '⚠️ لا يوجد اتصال بالإنترنت.\nتحقّق من الشبكة ثم أعد المحاولة.';
    }
    if (t.contains('timeout') ||
        t.contains('timed out') ||
        t.contains('deadline exceeded')) {
      return '⏳ انتهت مهلة الاتصال.\nحاول مجدداً بعد لحظات.';
    }
    if (t.contains('handshakeexception') ||
        t.contains('certificate') ||
        t.contains('ssl')) {
      return '🔐 مشكلة أمان مؤقتة أثناء الاتصال بالخادم.\nيرجى المحاولة لاحقاً.';
    }
    if (t.contains('formatexception') ||
        t.contains('unexpected character') ||
        t.contains('json')) {
      return '⚠️ حدث خلل في البيانات المستلمة.\nسنحاول إصلاحه، جرّب لاحقاً.';
    }
    return 'حدث خطأ غير متوقع.\nيرجى المحاولة لاحقاً.';
  }

  // ======================================================================

  // ======== كاش للسلة =========

  int _currentBranchId() {
    try {
      if (Get.isRegistered<BranchController>()) {
        return Get.find<BranchController>().selectedBranchId.value;
      }
    } catch (_) {}
    return 0;
  }

  String get _cartCacheKey => _userId == null
      ? 'cart_user_0_branch_${_currentBranchId()}'
      : 'cart_user_${_userId!}_branch_${_currentBranchId()}';

  Future<void> _saveCartToCache() async {
    if (_userId == null || _userId == 0) return;
    try {
      final sp = await SharedPreferences.getInstance();
      final data = {
        'cart': cart.toList(),
        'subtotal': subtotal.value,
        'delivery': delivery.value,
        'services': services.value,
      };
      await sp.setString(_cartCacheKey, jsonEncode(data));
    } catch (_) {
      // تجاهل بصمت
    }
  }

  Future<void> _loadCartFromCache() async {
    if (_userId == null || _userId == 0) return;
    try {
      final sp = await SharedPreferences.getInstance();
      final s = sp.getString(_cartCacheKey);
      if (s == null || s.isEmpty) return;

      final data = jsonDecode(s);
      if (data is! Map) return;

      final list = (data['cart'] as List?) ?? const [];
      final sub = (data['subtotal'] is num)
          ? (data['subtotal'] as num).toDouble()
          : double.tryParse('${data['subtotal'] ?? ''}') ?? 0.0;
      final del = (data['delivery'] is num)
          ? (data['delivery'] as num).toDouble()
          : double.tryParse('${data['delivery'] ?? ''}') ?? 0.0;
      final srv = (data['services'] is num)
          ? (data['services'] as num).toDouble()
          : double.tryParse('${data['services'] ?? ''}') ?? 0.0;

      cart.assignAll(
        list
            .map<Map<String, dynamic>>(
              (e) => Map<String, dynamic>.from(e as Map),
            )
            .toList(),
      );
      subtotal.value = sub;
      delivery.value = del;
      services.value = srv;
    } catch (_) {
      // تجاهل بصمت
    }
  }

  // ===========================================

  Future<void> clearForBranchChange() async {
    try {
      final sp = await SharedPreferences.getInstance();
      final keys = sp
          .getKeys()
          .where((k) => k.startsWith('cart_user_'))
          .toList();
      for (final k in keys) {
        await sp.remove(k);
      }
    } catch (_) {}

    cart.clear();
    subtotal.value = 0;
    delivery.value = 0;
    services.value = 0;
    selectedAddress.value = null;
    selectedAddressName.value = '';
    update();
  }

  @override
  void onInit() {
    super.onInit();
    // تحميل أولي مرة واحدة
    bindToCurrentUser();
  }

  /// تنادى بعد أي Login/Logout
  Future<void> bindToCurrentUser() async {
    _userId = await Session.userId();

    cart.clear();
    subtotal.value = 0;
    delivery.value = 0;
    services.value = 0;

    if (_userId != null && _userId! > 0) {
      // أولاً حاول تظهر آخر نسخة من الكاش
      await _loadCartFromCache();

      // ثم جِب الأحدث من السيرفر (لو متاح)
      await load();

      // === NEW: تحميل العنوان الافتراضي وعرضه في السلة
      await _loadDefaultAddressName();
    } else {
      selectedAddressName.value = '';
      selectedAddress.value = null;
    }

    update();
  }

  Future<void> load() async {
    if (_userId == null) return;
    isBusy.value = true;
    try {
      final r = await _api.get('get_cart.php', params: {'user_id': '$_userId'});

      if (r['ok'] == true) {
        final list = (r['cart'] as List).cast<Map<String, dynamic>>();

        for (final e in list) {
          // cart_item_id بأكثر من اسم محتمل
          final cartItemId =
              (e['cart_item_id'] ?? e['cart_id'] ?? e['id'] ?? 0);
          e['cart_item_id'] = (cartItemId is num)
              ? cartItemId.toInt()
              : int.tryParse('$cartItemId') ?? 0;

          // تطبيع الأنواع الأساسية
          final price = (e['price'] is num)
              ? (e['price'] as num).toDouble()
              : double.tryParse('${e['price']}') ?? 0.0;
          final qty = (e['quantity'] is num)
              ? (e['quantity'] as num).toInt()
              : int.tryParse('${e['quantity']}') ?? 0;

          // تطبيع الإضافات (addons = extras فعليًا)
          final rawAddons = (e['addons'] is List)
              ? e['addons'] as List
              : const [];
          final addons = rawAddons.map<Map<String, dynamic>>((a) {
            final m = Map<String, dynamic>.from(a as Map);
            final ap = (m['price'] is num)
                ? (m['price'] as num).toDouble()
                : double.tryParse('${m['price']}') ?? 0.0;
            final aq = (m['qty'] is num)
                ? (m['qty'] as num).toInt()
                : int.tryParse('${m['qty'] ?? 0}') ?? 0;

            return {
              'id': (m['id'] is num)
                  ? (m['id'] as num).toInt()
                  : int.tryParse('${m['id']}') ?? 0,
              'name': (m['name'] ?? '').toString(),
              'price': ap,
              'qty': aq,
              'image_url': (m['image_url'] ?? '').toString(),
            };
          }).toList();

          // ✅ دعم كل الأسماء/الأشكال المحتملة لقائمة المحذوفات
          dynamic rawRem = e['removals'];
          rawRem ??= e['components_rem'];
          rawRem ??= e['removes'];
          rawRem ??= e['removed'];
          rawRem ??= e['item_removes'];

          final List<Map<String, dynamic>> removals = <Map<String, dynamic>>[];
          if (rawRem is List) {
            for (final x in rawRem) {
              if (x is Map) {
                final m = Map<String, dynamic>.from(x);
                removals.add({
                  'id': (m['id'] is num)
                      ? (m['id'] as num).toInt()
                      : int.tryParse('${m['id']}') ?? 0,
                  'name': (m['name'] ?? m['title'] ?? m['label'] ?? '')
                      .toString(),
                });
              } else {
                removals.add({'id': 0, 'name': x.toString()});
              }
            }
          }

          // مجموع الإضافات (لسعر القطعة الواحدة)
          final addonsTotalPerUnit = addons.fold<double>(
            0.0,
            (s, a) => s + ((a['price'] as double) * (a['qty'] as int)),
          );

          // unit_total (سعر القطعة بعد الإضافات) من السيرفر أو نحسبه
          final serverUnitTotal = (e['unit_total'] is num)
              ? (e['unit_total'] as num).toDouble()
              : double.tryParse('${e['unit_total'] ?? ''}');
          final unitTotal = serverUnitTotal ?? (price + addonsTotalPerUnit);

          // line_total من السيرفر (إن وُجد) أو احسبه محليًا
          final serverLineTotal = (e['line_total'] is num)
              ? (e['line_total'] as num).toDouble()
              : double.tryParse('${e['line_total'] ?? ''}');
          final lineTotal = serverLineTotal ?? (unitTotal * qty);

          // short_desc (لو مرجع من السيرفر)
          e['short_desc'] = (e['short_desc'] ?? '').toString();

          e['price'] = price;
          e['quantity'] = qty;
          e['addons'] = addons;
          e['removals'] = removals;

          // ✅ نحفظها مهما كان اسم الحقل الأصلي
          e['unit_total'] = unitTotal;
          e['line_total'] = lineTotal;
        }

        cart.assignAll(list);

        // subtotal من السيرفر (إن وُجد) أو احسبه محليًا
        final serverSubtotal = (r['subtotal'] is num)
            ? (r['subtotal'] as num).toDouble()
            : double.tryParse('${r['subtotal'] ?? ''}');
        subtotal.value =
            serverSubtotal ??
            cart.fold<double>(
              0.0,
              (s, e) => s + ((e['line_total'] as num).toDouble()),
            );

        // ← جديد: حفظ نسخة من السلة في الكاش
        await _saveCartToCache();
      }
    } catch (e) {
      _showUserError(_friendlyMessage(e), onRetry: () => load());

      // لو فيه مشكلة نت حاول نعرض آخر نسخة من الكاش
      await _loadCartFromCache();
    } finally {
      isBusy.value = false;
    }
  }

  // ===================== بالـ item_id (قديمة) =====================

  Future<void> add(int itemId, {int qty = 1}) async {
    if (_userId == null) return;
    try {
      await _api.post(
        'add_to_cart.php',
        body: {'user_id': '$_userId', 'item_id': '$itemId', 'quantity': '$qty'},
      );
      await load();
    } catch (e) {
      _showUserError(_friendlyMessage(e), onRetry: () => add(itemId, qty: qty));
    }
  }

  Future<void> setQty(int itemId, int qty) async {
    if (_userId == null) return;
    try {
      await _api.post(
        'update_cart_item.php',
        body: {
          'user_id': '$_userId',
          'item_id': '$itemId',
          'quantity': '$qty', // 0 = حذف
        },
      );
      await load();
    } catch (e) {
      _showUserError(_friendlyMessage(e), onRetry: () => setQty(itemId, qty));
    }
  }

  Future<void> inc(int itemId) async {
    final row = cart.firstWhereOrNull((e) => (e['item_id'] as int) == itemId);
    final q = ((row?['quantity'] as int?) ?? 0) + 1;
    await setQty(itemId, q);
  }

  Future<void> dec(int itemId) async {
    final row = cart.firstWhereOrNull((e) => (e['item_id'] as int) == itemId);
    final q = ((row?['quantity'] as int?) ?? 0) - 1;
    await setQty(itemId, q < 0 ? 0 : q);
  }

  Future<void> remove(int itemId) async {
    if (_userId == null) return;
    try {
      await _api.post(
        'remove_cart_item.php',
        body: {'user_id': '$_userId', 'item_id': '$itemId'},
      );
      await load();
    } catch (e) {
      _showUserError(_friendlyMessage(e), onRetry: () => remove(itemId));
    }
  }

  // ===================== بالـ cart_item_id (جديدة) =====================

  Future<void> setQtyByCartId(int cartItemId, int qty) async {
    if (_userId == null) return;

    // نرسل cart_item_id + item_id (اختياري) لمرونة الـ PHP
    final itemId = _findItemIdByCartId(cartItemId);

    try {
      await _api.post(
        'update_cart_item.php',
        body: {
          'user_id': '$_userId',
          'cart_item_id': '$cartItemId',
          if (itemId != null) 'item_id': '$itemId',
          'quantity': '$qty', // 0 = حذف
        },
      );
      await load();
    } catch (e) {
      _showUserError(
        _friendlyMessage(e),
        onRetry: () => setQtyByCartId(cartItemId, qty),
      );
    }
  }

  Future<void> incByCartId(int cartItemId) async {
    final row = cart.firstWhereOrNull(
      (e) => (e['cart_item_id'] as int) == cartItemId,
    );
    final q = ((row?['quantity'] as int?) ?? 0) + 1;
    await setQtyByCartId(cartItemId, q);
  }

  Future<void> decByCartId(int cartItemId) async {
    final row = cart.firstWhereOrNull(
      (e) => (e['cart_item_id'] as int) == cartItemId,
    );
    final q = ((row?['quantity'] as int?) ?? 0) - 1;
    await setQtyByCartId(cartItemId, q < 0 ? 0 : q);
  }

  Future<void> removeByCartId(int cartItemId) async {
    if (_userId == null) return;
    final itemId = _findItemIdByCartId(cartItemId);
    try {
      await _api.post(
        'remove_cart_item.php',
        body: {
          'user_id': '$_userId',
          'cart_item_id': '$cartItemId',
          if (itemId != null) 'item_id': '$itemId',
        },
      );
      await load();
    } catch (e) {
      _showUserError(
        _friendlyMessage(e),
        onRetry: () => removeByCartId(cartItemId),
      );
    }
  }

  int? _findItemIdByCartId(int cartItemId) {
    final row = cart.firstWhereOrNull(
      (e) => (e['cart_item_id'] as int) == cartItemId,
    );
    return (row?['item_id'] as int?);
  }

  // ===================== الإضافات (extras) =====================

  /// تعيين كمية إضافة (0 = حذف) بالـ item_id (قديمة)
  Future<void> setAddonQty(int itemId, int addonId, int qty) async {
    if (_userId == null) return;
    try {
      await _api.post(
        'update_cart_extra.php',
        body: {
          'user_id': '$_userId',
          'item_id': '$itemId',
          'extra_id': '$addonId', // اسم الحقل في الـ PHP
          'qty': '$qty',
        },
      );
      await load();
    } catch (e) {
      _showUserError(
        _friendlyMessage(e),
        onRetry: () => setAddonQty(itemId, addonId, qty),
      );
    }
  }

  Future<void> incAddon(int itemId, int addonId) async {
    final row = cart.firstWhereOrNull((e) => (e['item_id'] as int) == itemId);
    if (row == null) return;
    final addons = (row['addons'] as List).cast<Map<String, dynamic>>();
    final m = addons.firstWhereOrNull((a) => (a['id'] as int) == addonId);
    final current = (m?['qty'] as num?)?.toInt() ?? 0;
    await setAddonQty(itemId, addonId, current + 1);
  }

  Future<void> decAddon(int itemId, int addonId) async {
    final row = cart.firstWhereOrNull((e) => (e['item_id'] as int) == itemId);
    if (row == null) return;
    final addons = (row['addons'] as List).cast<Map<String, dynamic>>();
    final m = addons.firstWhereOrNull((a) => (a['id'] as int) == addonId);
    final current = (m?['qty'] as num?)?.toInt() ?? 0;
    final next = current - 1;
    await setAddonQty(itemId, addonId, next < 0 ? 0 : next);
  }

  /// تعيين كمية إضافة (0 = حذف) بالـ cart_item_id (جديدة)
  Future<void> setAddonQtyByCartId(int cartItemId, int addonId, int qty) async {
    if (_userId == null) return;
    final itemId = _findItemIdByCartId(cartItemId);
    try {
      await _api.post(
        'update_cart_extra.php',
        body: {
          'user_id': '$_userId',
          'cart_item_id': '$cartItemId',
          if (itemId != null) 'item_id': '$itemId',
          'extra_id': '$addonId',
          'qty': '$qty',
        },
      );
      await load();
    } catch (e) {
      _showUserError(
        _friendlyMessage(e),
        onRetry: () => setAddonQtyByCartId(cartItemId, addonId, qty),
      );
    }
  }

  Future<void> incAddonByCartId(int cartItemId, int addonId) async {
    final row = cart.firstWhereOrNull(
      (e) => (e['cart_item_id'] as int) == cartItemId,
    );
    if (row == null) return;
    final addons = (row['addons'] as List).cast<Map<String, dynamic>>();
    final m = addons.firstWhereOrNull((a) => (a['id'] as int) == addonId);
    final current = (m?['qty'] as num?)?.toInt() ?? 0;
    await setAddonQtyByCartId(cartItemId, addonId, current + 1);
  }

  Future<void> decAddonByCartId(int cartItemId, int addonId) async {
    final row = cart.firstWhereOrNull(
      (e) => (e['cart_item_id'] as int) == cartItemId,
    );
    if (row == null) return;
    final addons = (row['addons'] as List).cast<Map<String, dynamic>>();
    final m = addons.firstWhereOrNull((a) => (a['id'] as int) == addonId);
    final current = (m?['qty'] as num?)?.toInt() ?? 0;
    final next = current - 1;
    await setAddonQtyByCartId(cartItemId, addonId, next < 0 ? 0 : next);
  }

  // === تعيين العنوان المختار يدويًا (لو جاك من شاشة العناوين) =====
  void setSelectedAddress(Address a) {
    selectedAddress.value = a;

    // ✅ هنا التعديل: حفظ اسم العنوان للعرض في واجهة السلة
    // نستخدم label، ولو حبيت توسّع ممكن تستخدم addressText أو دمج الاثنين
    final displayName = (a.label.isNotEmpty ? a.label : a.addressText).trim();
    selectedAddressName.value = displayName;

    update(); // لو عندك عناصر GetBuilder
  }

  // === NEW: تحميل اسم / كائن العنوان الافتراضي من الـ API ================
  Future<void> _loadDefaultAddressName() async {
    if (_userId == null || _userId == 0) {
      selectedAddressName.value = '';
      selectedAddress.value = null;
      return;
    }

    try {
      final res = await _api.get(
        'get_user_addresses.php',
        params: {
          'user_id': '$_userId',
          't': '${DateTime.now().millisecondsSinceEpoch}',
        },
      );

      dynamic jsonObj = res;
      if (res is String) {
        try {
          jsonObj = jsonDecode(res);
        } catch (_) {}
      }

      List list = const [];
      if (jsonObj is Map &&
          jsonObj['status'] == 'success' &&
          jsonObj['data'] is List) {
        list = jsonObj['data'];
      } else if (jsonObj is Map && jsonObj['addresses'] is List) {
        list = jsonObj['addresses'];
      } else if (jsonObj is List) {
        list = jsonObj;
      }

      if (list.isEmpty) {
        selectedAddressName.value = '';
        selectedAddress.value = null;
        return;
      }

      Map<String, dynamic>? def;
      for (final e in list) {
        final m = Map<String, dynamic>.from(e as Map);
        final isDefStr =
            (m['is_default'] ?? m['default'] ?? m['isDefault'] ?? 0).toString();
        final isDef = isDefStr == '1' || isDefStr.toLowerCase() == 'true';
        if (isDef) {
          def = m;
          break;
        }
      }

      def ??= Map<String, dynamic>.from(list.first as Map);

      // ✅ محاولة بناء Address كامل من الـ Map
      Address? addr;
      try {
        addr = Address.fromJson(def);
      } catch (_) {
        // لو factory مختلفة أو فشل البارسينغ، نكمل باسم فقط
      }

      if (addr != null) {
        selectedAddress.value = addr;
        final nameFromAddr = addr.label.trim().isNotEmpty
            ? addr.label.trim()
            : addr.addressText.trim();
        selectedAddressName.value = nameFromAddr;
        return;
      }

      // لو ما قدرنا نبني Address، نرجع للسلوك القديم (اسم فقط)
      final fallbackName = (def['name'] ?? def['label'] ?? def['title'] ?? '')
          .toString()
          .trim();

      selectedAddressName.value = fallbackName;
    } catch (e) {
      debugPrint('load default address for cart error: $e');
      // لو في مشكلة، نخلي القيم زي ما هي
    }
  }

  // ================================================================

  // تنظيف السلة بالكامل
  Future<void> clear() async {
    if (_userId == null) return;
    try {
      await _api.post('clear_cart.php', body: {'user_id': '$_userId'});
      await load();
    } catch (e) {
      // محاولة بديلة كما هو منطقك + إظهار رسالة لو فشلت كلياً
      try {
        final ids = cart.map<int>((e) => e['item_id'] as int).toList();
        for (final id in ids) {
          try {
            await _api.post(
              'remove_cart_item.php',
              body: {'user_id': '$_userId', 'item_id': '$id'},
            );
          } catch (_) {}
        }
        await load();
      } catch (_) {
        _showUserError(_friendlyMessage(e), onRetry: () => clear());
      }
    }
  }
}
