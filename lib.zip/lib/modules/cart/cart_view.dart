import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mandena/app_routes.dart';
import 'package:mandena/data/models/address.dart';

import 'package:mandena/modules/cart/cart_controller.dart';
import 'package:mandena/modules/checkout/checkout_view.dart';

const _brown = Color(0xFF6F3F17);
const _gold = Color(0xFFC49A3C);
const _light = Color(0xFFF7F4EF);
const _border = Color(0xFFE8E5E0);

// ───────────────────────────── Header Gradient ────────────────────────────────
final _headerGradient = const LinearGradient(
  colors: [Color(0xFFC49A3C), Color(0xFF6F3F17)],
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
);

class CartView extends StatelessWidget {
  const CartView({super.key});

  @override
  Widget build(BuildContext context) {
    final c = Get.find<CartController>();
    final theme = Theme.of(context);
    final scaffoldBg = theme.scaffoldBackgroundColor;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: scaffoldBg,
        body: Column(
          children: [
            // ── الهيدر الذهبي ──
            _CartHeader(c: c),

            // ── المحتوى ──
            Expanded(
              child: Obx(() {
                if (c.isBusy.value) {
                  return const Center(
                    child: CircularProgressIndicator(color: _brown),
                  );
                }
                if (c.cart.isEmpty) {
                  return const _EmptyCartView();
                }
                return Column(
                  children: [
                    // كرت اختيار العنوان
                    _AddressCard(c: c),

                    // قائمة الأصناف
                    Expanded(
                      child: ListView.separated(
                        padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
                        itemCount: c.cart.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 10),
                        itemBuilder: (_, i) {
                          final e = c.cart[i];
                          final String name = (e['name'] ?? '').toString();
                          final int cartItemId =
                              (e['cart_item_id'] ??
                                      e['cart_id'] ??
                                      e['id'] ??
                                      0)
                                  is num
                              ? ((e['cart_item_id'] ??
                                            e['cart_id'] ??
                                            e['id'] ??
                                            0)
                                        as num)
                                    .toInt()
                              : int.tryParse(
                                      '${e['cart_item_id'] ?? e['cart_id'] ?? e['id'] ?? 0}',
                                    ) ??
                                    0;
                          final double basePrice = (e['price'] is num)
                              ? (e['price'] as num).toDouble()
                              : double.tryParse('${e['price'] ?? 0}') ?? 0.0;
                          final double unitTotal = (e['unit_total'] is num)
                              ? (e['unit_total'] as num).toDouble()
                              : double.tryParse('${e['unit_total'] ?? ''}') ??
                                    basePrice;
                          final int qty = (e['quantity'] as num).toInt();
                          final String img = (e['image_url'] ?? '').toString();
                          final String shortDesc = (e['short_desc'] ?? '')
                              .toString()
                              .trim();
                          final List<Map<String, dynamic>> addons =
                              (e['addons'] is List)
                              ? (e['addons'] as List)
                                    .cast<Map<String, dynamic>>()
                              : const [];
                          final List<Map<String, dynamic>> removals =
                              (e['removals'] is List)
                              ? (e['removals'] as List)
                                    .cast<Map<String, dynamic>>()
                              : (e['components_rem'] is List)
                              ? (e['components_rem'] as List)
                                    .cast<Map<String, dynamic>>()
                              : const [];

                          return _CartItemCard(
                            itemId: (e['item_id'] as num?)?.toInt() ?? 0,
                            imageUrl: img,
                            title: name,
                            price: unitTotal,
                            qty: qty,
                            addons: addons,
                            removals: removals,
                            shortDesc: shortDesc,
                            onInc: () => c.incByCartId(cartItemId),
                            onDec: () => c.decByCartId(cartItemId),
                            onRemove: () => c.removeByCartId(cartItemId),
                            onAddonInc: (addonId, current) =>
                                c.incAddonByCartId(cartItemId, addonId),
                            onAddonDec: (addonId, current) =>
                                c.decAddonByCartId(cartItemId, addonId),
                          );
                        },
                      ),
                    ),

                    // ملخص + كوبون + زر الطلب
                    _SummaryBlock(
                      subtotal: c.subtotal.value,
                      delivery: c.delivery.value,
                      services: c.services.value,
                      total: c.total,
                      onCheckout: () => Get.to(() => const CheckoutView()),
                    ),
                  ],
                );
              }),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────── Cart Header ──────────────────────────────────────

class _CartHeader extends StatelessWidget {
  const _CartHeader({required this.c});
  final CartController c;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(gradient: _headerGradient),
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 12,
        bottom: 18,
        left: 16,
        right: 16,
      ),
      child: Row(
        children: [
          // زر الرجوع
          GestureDetector(
            onTap: Get.back,
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(
                Icons.arrow_back_ios_new_rounded,
                color: Colors.white,
                size: 18,
              ),
            ),
          ),
          const Spacer(),
          // العنوان
          const Text(
            'سلة التسوق',
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.w800,
            ),
          ),
          const Spacer(),
          // عداد الأصناف
          Obx(() {
            final count = c.cart.length;
            return Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                '$count ${count == 1 ? 'صنف' : 'أصناف'}',
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 13,
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}

// ─────────────────────────── Address Card ─────────────────────────────────────

class _AddressCard extends StatelessWidget {
  const _AddressCard({required this.c});
  final CartController c;

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final theme = Theme.of(context);
      final isDark = theme.brightness == Brightness.dark;
      final cardColor = theme.cardColor;
      final borderColor = theme.dividerColor.withOpacity(isDark ? 0.4 : 0.7);
      final subtitleColor = (theme.textTheme.bodySmall?.color ?? Colors.black54)
          .withOpacity(isDark ? 0.7 : 0.6);

      final String defaultLabel = c.selectedAddressName.value.trim();
      final bool hasSelected =
          defaultLabel.isNotEmpty || c.selectedAddress.value != null;
      final String label = defaultLabel.isNotEmpty
          ? defaultLabel
          : (c.selectedAddress.value?.label ?? 'اختر العنوان');
      final String subtitle = hasSelected
          ? 'هذا هو عنوان التوصيل الحالي'
          : 'اختر عنوان محفوظ للتوصيل';

      return Container(
        margin: const EdgeInsets.fromLTRB(12, 10, 12, 4),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: borderColor),
          boxShadow: [
            BoxShadow(
              color: isDark
                  ? Colors.black.withOpacity(.35)
                  : Colors.black.withOpacity(.04),
              blurRadius: 10,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: ListTile(
          contentPadding: EdgeInsets.zero,
          leading: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: const Color(0xFFEFE2D7),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(
              Icons.location_on_outlined,
              color: _brown,
              size: 20,
            ),
          ),
          title: Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
          subtitle: Text(
            subtitle,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: 11.5, color: subtitleColor),
          ),
          trailing: const Icon(Icons.chevron_left, color: _brown),
          onTap: () async {
            final result = await Get.toNamed(
              AppRoutes.addresses,
              arguments: {'pickMode': true},
            );
            if (result != null && result is Address) {
              c.setSelectedAddress(result);
            }
          },
        ),
      );
    });
  }
}

// ─────────────────────────── Cart Item Card ───────────────────────────────────

class _CartItemCard extends StatelessWidget {
  const _CartItemCard({
    required this.itemId,
    required this.imageUrl,
    required this.title,
    required this.price,
    required this.qty,
    required this.onInc,
    required this.onDec,
    required this.onRemove,
    required this.addons,
    required this.removals,
    required this.onAddonInc,
    required this.onAddonDec,
    this.shortDesc = '',
  });

  final int itemId;
  final String imageUrl;
  final String title;
  final double price;
  final int qty;
  final VoidCallback onInc, onDec, onRemove;
  final List<Map<String, dynamic>> addons;
  final List<Map<String, dynamic>> removals;
  final void Function(int addonId, int currentQty) onAddonInc;
  final void Function(int addonId, int currentQty) onAddonDec;
  final String shortDesc;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final cardColor = theme.cardColor;
    final borderColor = theme.dividerColor.withOpacity(isDark ? 0.35 : 0.6);
    final subTextColor = (theme.textTheme.bodySmall?.color ?? Colors.black54)
        .withOpacity(isDark ? 0.7 : 0.55);

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(isDark ? 0.2 : 0.06),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // أيقونة الحذف
              GestureDetector(
                onTap: onRemove,
                child: Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: Colors.red.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(
                    Icons.delete_outline_rounded,
                    color: Colors.red,
                    size: 20,
                  ),
                ),
              ),
              const SizedBox(width: 10),

              // الاسم + السعر
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.right,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w700,
                        fontSize: 15,
                      ),
                    ),
                    if (shortDesc.isNotEmpty) ...[
                      const SizedBox(height: 3),
                      Text(
                        shortDesc,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.right,
                        style: TextStyle(fontSize: 12, color: subTextColor),
                      ),
                    ],
                    const SizedBox(height: 6),
                    Text(
                      'ر.س ${price.toStringAsFixed(0)}',
                      textAlign: TextAlign.right,
                      style: const TextStyle(
                        color: _gold,
                        fontWeight: FontWeight.w800,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),

              // الصورة
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: imageUrl.isNotEmpty
                    ? Image.network(
                        imageUrl,
                        width: 78,
                        height: 78,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          width: 78,
                          height: 78,
                          color: theme.colorScheme.surfaceContainerHighest,
                        ),
                      )
                    : Container(
                        width: 78,
                        height: 78,
                        color: theme.colorScheme.surfaceContainerHighest,
                      ),
              ),
            ],
          ),

          const SizedBox(height: 10),

          // عداد الكمية + الإجمالي
          Row(
            children: [
              // الإجمالي
              Text(
                'ر.س ${(price * qty).toStringAsFixed(0)}',
                style: const TextStyle(
                  color: _brown,
                  fontWeight: FontWeight.w800,
                  fontSize: 15,
                ),
              ),
              const Spacer(),
              // عداد
              Container(
                decoration: BoxDecoration(
                  color: _brown,
                  borderRadius: BorderRadius.circular(30),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _stepBtn(Icons.add, onInc),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Text(
                        '$qty',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 15,
                        ),
                      ),
                    ),
                    _stepBtn(Icons.remove, onDec),
                  ],
                ),
              ),
            ],
          ),

          // ====== الإضافات ======
          if (addons.isNotEmpty) ...[
            const SizedBox(height: 10),
            Divider(height: 1, color: borderColor),
            const SizedBox(height: 10),
            const Align(
              alignment: Alignment.centerRight,
              child: Text(
                'إضافات',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              height: 96,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 4),
                itemCount: addons.length,
                separatorBuilder: (_, __) => const SizedBox(width: 10),
                itemBuilder: (_, i) {
                  final a = addons[i];
                  final int id = (a['id'] as num?)?.toInt() ?? 0;
                  final String name = (a['name'] ?? '').toString();
                  final double p = (a['price'] is num)
                      ? (a['price'] as num).toDouble()
                      : double.tryParse('${a['price']}') ?? 0.0;
                  final int q = (a['qty'] is num)
                      ? (a['qty'] as num).toInt()
                      : int.tryParse('${a['qty'] ?? 0}') ?? 0;
                  final String img = (a['image_url'] ?? '').toString();
                  return _AddonCard(
                    name: name,
                    price: p,
                    qty: q,
                    imageUrl: img,
                    onPlus: () => onAddonInc(id, q),
                    onMinus: () => onAddonDec(id, q),
                  );
                },
              ),
            ),
          ],

          // ====== المحذوفات ======
          if (removals.isNotEmpty) ...[
            const SizedBox(height: 10),
            Divider(height: 1, color: borderColor),
            const SizedBox(height: 10),
            const Align(
              alignment: Alignment.centerRight,
              child: Text(
                'محذوفات',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: removals.map((m) {
                  final name = (m['name'] ?? '').toString();
                  return Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: theme.cardColor,
                      border: Border.all(color: borderColor),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.block, size: 14, color: Colors.red),
                        const SizedBox(width: 6),
                        Text(
                          name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 12),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _stepBtn(IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 32,
        height: 32,
        decoration: const BoxDecoration(
          color: Colors.white24,
          shape: BoxShape.circle,
        ),
        alignment: Alignment.center,
        child: Icon(icon, color: Colors.white, size: 16),
      ),
    );
  }
}

// ─────────────────────────── Summary Block ────────────────────────────────────

class _SummaryBlock extends StatelessWidget {
  const _SummaryBlock({
    required this.subtotal,
    required this.delivery,
    required this.services,
    required this.total,
    required this.onCheckout,
  });

  final double subtotal, delivery, services, total;
  final VoidCallback onCheckout;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final bgPanel = isDark ? theme.colorScheme.surfaceContainerHighest : _light;
    final couponCtrl = TextEditingController();

    return Container(
      decoration: BoxDecoration(
        color: bgPanel,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(22)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(isDark ? 0.3 : 0.08),
            blurRadius: 16,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // ── حقل الكوبون ──
          Row(
            children: [
              Expanded(
                child: Container(
                  height: 44,
                  decoration: BoxDecoration(
                    color: theme.cardColor,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _border),
                  ),
                  child: TextField(
                    controller: couponCtrl,
                    textAlign: TextAlign.right,
                    decoration: InputDecoration(
                      hintText: 'أدخل الكوبون',
                      hintStyle: TextStyle(
                        color: Colors.grey.shade400,
                        fontSize: 13,
                      ),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 12,
                      ),
                      suffixIcon: const Icon(
                        Icons.local_offer_outlined,
                        color: _gold,
                        size: 18,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  backgroundColor: _brown,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 18,
                    vertical: 12,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text(
                  'تطبيق',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          // ── ملخص الطلب ──
          const Align(
            alignment: Alignment.centerRight,
            child: Text(
              'ملخص الطلب',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
            ),
          ),
          const SizedBox(height: 10),
          _summaryRow(
            'المجموع الفرعي',
            'ر.س ${subtotal.toStringAsFixed(0)}',
            theme,
          ),
          const SizedBox(height: 6),
          _summaryRow(
            'رسوم التوصيل',
            'ر.س ${delivery.toStringAsFixed(0)}',
            theme,
          ),
          const Divider(height: 20),
          Row(
            children: [
              Text(
                'ر.س ${total.toStringAsFixed(2)}',
                style: const TextStyle(
                  fontWeight: FontWeight.w900,
                  fontSize: 18,
                  color: _brown,
                ),
              ),
              const Spacer(),
              const Text(
                'الإجمالي',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16),
              ),
            ],
          ),
          const SizedBox(height: 14),
          // ── زر إتمام الطلب ──
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton(
              onPressed: onCheckout,
              style: ElevatedButton.styleFrom(
                backgroundColor: _brown,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                elevation: 0,
              ),
              child: const Text(
                'إتمام الطلب',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _summaryRow(String label, String value, ThemeData theme) {
    return Row(
      children: [
        Text(
          value,
          style: theme.textTheme.bodyMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        const Spacer(),
        Text(
          label,
          style: theme.textTheme.bodyMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────── Empty Cart ───────────────────────────────────────

class _EmptyCartView extends StatelessWidget {
  const _EmptyCartView();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final titleColor = theme.textTheme.titleMedium?.color ?? Colors.black87;
    final bodyColor = (theme.textTheme.bodyMedium?.color ?? Colors.black54)
        .withOpacity(0.8);

    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                color: const Color(0xFFEFE2D7),
                borderRadius: BorderRadius.circular(50),
              ),
              child: const Icon(
                Icons.shopping_bag_outlined,
                size: 48,
                color: _brown,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'السلة فارغة حالياً',
              style: TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 18,
                color: titleColor,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'ابدأ بإضافة أصنافك المفضّلة من القائمة الرئيسية',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13.5, height: 1.4, color: bodyColor),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: Get.back,
              style: ElevatedButton.styleFrom(
                backgroundColor: _brown,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 12,
                ),
              ),
              icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 16),
              label: const Text(
                'رجوع للتسوّق',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────── Addon Card ───────────────────────────────────────

class _AddonCard extends StatelessWidget {
  const _AddonCard({
    required this.name,
    required this.price,
    required this.qty,
    required this.imageUrl,
    required this.onPlus,
    required this.onMinus,
  });

  final String name;
  final double price;
  final int qty;
  final String imageUrl;
  final VoidCallback onPlus, onMinus;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cardColor = theme.cardColor;
    final borderColor = theme.dividerColor.withOpacity(0.8);
    final priceColor = (theme.textTheme.bodySmall?.color ?? Colors.black54)
        .withOpacity(0.8);

    return Container(
      width: 96,
      decoration: BoxDecoration(
        color: cardColor,
        border: Border.all(color: borderColor),
        borderRadius: BorderRadius.circular(12),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0F000000),
            blurRadius: 6,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned.fill(
            top: 6,
            left: 6,
            right: 6,
            bottom: 28,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: imageUrl.isNotEmpty
                  ? Image.network(imageUrl, fit: BoxFit.cover)
                  : Container(color: theme.colorScheme.surfaceContainerHighest),
            ),
          ),
          Positioned(
            left: 6,
            right: 6,
            bottom: 4,
            child: Column(
              children: [
                Text(
                  name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12),
                ),
                if (price > 0)
                  Text(
                    'ر.س ${price.toStringAsFixed(0)}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 11, color: priceColor),
                  ),
              ],
            ),
          ),
          Positioned(top: 6, right: 8, child: _tinyBtn(Icons.add, onPlus)),
          Positioned(top: 6, left: 8, child: _tinyBtn(Icons.remove, onMinus)),
          if (qty > 0)
            Positioned(
              top: 6,
              left: 0,
              right: 0,
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 6,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFF2FBF71),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    '$qty',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _tinyBtn(IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 22,
        height: 22,
        decoration: const BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: Color(0x1A000000),
              blurRadius: 4,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Icon(icon, size: 14, color: _brown),
      ),
    );
  }
}
