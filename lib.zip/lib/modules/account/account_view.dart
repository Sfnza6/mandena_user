import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'account_controller.dart';

class AccountView extends GetView<AccountController> {
  const AccountView({super.key});

  static const Color kPrimary = Color(0xFFFF5A00);
  static const Color kPrimaryDark = Color(0xFFE14D00);
  static const Color kPageBg = Color(0xFFF7F4EF);
  static const Color kCard = Colors.white;
  static const Color kText = Color(0xFF241A12);
  static const Color kMuted = Color(0xFF8B8B95);
  static const Color kBorder = Color(0xFFE9E3DA);

  @override
  Widget build(BuildContext context) {
    if (!Get.isRegistered<AccountController>()) {
      Get.put(AccountController(), permanent: true);
    }

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: kPageBg,
        body: RefreshIndicator(
          onRefresh: controller.fetchProfile,
          color: kPrimary,
          child: Obx(() {
            final u = controller.user.value;

            return CustomScrollView(
              physics: const BouncingScrollPhysics(
                parent: AlwaysScrollableScrollPhysics(),
              ),
              slivers: [
                SliverToBoxAdapter(
                  child: Container(
                    width: double.infinity,
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [kPrimary, kPrimaryDark],
                      ),
                      borderRadius: BorderRadius.vertical(
                        bottom: Radius.circular(28),
                      ),
                    ),
                    padding: EdgeInsets.fromLTRB(
                      20,
                      MediaQuery.of(context).padding.top + 18,
                      20,
                      30,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        const Text(
                          'حسابي',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 22,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 18),
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(.12),
                            borderRadius: BorderRadius.circular(18),
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 72,
                                height: 72,
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(.18),
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(
                                  Icons.person_outline_rounded,
                                  color: Colors.white,
                                  size: 36,
                                ),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: controller.loading.value && u == null
                                    ? const SizedBox(
                                        height: 44,
                                        child: Center(
                                          child: CircularProgressIndicator(
                                            color: Colors.white,
                                            strokeWidth: 2,
                                          ),
                                        ),
                                      )
                                    : Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.end,
                                        children: [
                                          Text(
                                            u?.username.isNotEmpty == true
                                                ? u!.username
                                                : 'المستخدم',
                                            textAlign: TextAlign.right,
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight.w900,
                                              fontSize: 18,
                                            ),
                                          ),
                                          const SizedBox(height: 6),
                                          Text(
                                            u?.phone ?? '',
                                            textAlign: TextAlign.right,
                                            style: TextStyle(
                                              color: Colors.white.withOpacity(
                                                .9,
                                              ),
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                        ],
                                      ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                SliverToBoxAdapter(
                  child: Transform.translate(
                    offset: const Offset(0, -18),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        decoration: BoxDecoration(
                          color: kCard,
                          borderRadius: BorderRadius.circular(18),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(.06),
                              blurRadius: 14,
                              offset: const Offset(0, 5),
                            ),
                          ],
                        ),
                        child: const Row(
                          children: [
                            Expanded(
                              child: _StatItem(value: '145', label: 'نقطة'),
                            ),
                            _DividerV(),
                            Expanded(
                              child: _StatItem(value: '8', label: 'عنوان'),
                            ),
                            _DividerV(),
                            Expanded(
                              child: _StatItem(value: '12', label: 'طلب'),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),

                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                    child: Container(
                      decoration: BoxDecoration(
                        color: kCard,
                        borderRadius: BorderRadius.circular(18),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(.06),
                            blurRadius: 14,
                            offset: const Offset(0, 5),
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          _MenuTile(
                            title: 'الطلبات السابقة',
                            icon: Icons.receipt_long_outlined,
                            badge: '12',
                            onTap: controller.goToOrders,
                          ),
                          const Divider(height: 1, color: kBorder),
                          _MenuTile(
                            title: 'العناوين المحفوظة',
                            icon: Icons.location_on_outlined,
                            onTap: controller.goToAddress,
                          ),
                          const Divider(height: 1, color: kBorder),
                          _MenuTile(
                            title: 'طرق الدفع',
                            icon: Icons.credit_card_outlined,
                            onTap: () {},
                          ),
                          const Divider(height: 1, color: kBorder),
                          _MenuTile(
                            title: 'الإشعارات',
                            icon: Icons.notifications_none_rounded,
                            onTap: () {},
                          ),
                          const Divider(height: 1, color: kBorder),
                          _MenuTile(
                            title: 'الإعدادات',
                            icon: Icons.settings_outlined,
                            onTap: controller.toggleDarkMode,
                          ),
                          const Divider(height: 1, color: kBorder),
                          _MenuTile(
                            title: 'المساعدة والدعم',
                            icon: Icons.help_outline_rounded,
                            onTap: controller.openDevelopers,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: controller.logout,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 18,
                          vertical: 18,
                        ),
                        decoration: BoxDecoration(
                          color: kCard,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(.05),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: const Row(
                          children: [
                            Icon(Icons.logout_rounded, color: Colors.red),
                            SizedBox(width: 10),
                            Text(
                              'تسجيل الخروج',
                              style: TextStyle(
                                color: Colors.red,
                                fontWeight: FontWeight.w800,
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),

                const SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.only(bottom: 28),
                    child: Center(
                      child: Text(
                        'الإصدار 1.0.0',
                        style: TextStyle(color: kMuted, fontSize: 11.5),
                      ),
                    ),
                  ),
                ),
              ],
            );
          }),
        ),
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  const _StatItem({required this.value, required this.label});

  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            color: AccountView.kPrimary,
            fontWeight: FontWeight.w900,
            fontSize: 22,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
            color: AccountView.kMuted,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}

class _DividerV extends StatelessWidget {
  const _DividerV();

  @override
  Widget build(BuildContext context) {
    return Container(width: 1, height: 38, color: AccountView.kBorder);
  }
}

class _MenuTile extends StatelessWidget {
  const _MenuTile({
    required this.title,
    required this.icon,
    required this.onTap,
    this.badge,
  });

  final String title;
  final IconData icon;
  final VoidCallback onTap;
  final String? badge;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: const Icon(
        Icons.chevron_left_rounded,
        color: AccountView.kMuted,
      ),
      title: Align(
        alignment: Alignment.centerRight,
        child: Text(
          title,
          textAlign: TextAlign.right,
          style: const TextStyle(
            color: AccountView.kText,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
      trailing: Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: const Color(0xFFFFF3EA),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(icon, color: AccountView.kPrimary),
      ),
      subtitle: badge != null
          ? Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Align(
                alignment: Alignment.centerRight,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFF3EA),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    badge!,
                    style: const TextStyle(
                      color: AccountView.kPrimary,
                      fontWeight: FontWeight.w800,
                      fontSize: 11,
                    ),
                  ),
                ),
              ),
            )
          : null,
    );
  }
}
