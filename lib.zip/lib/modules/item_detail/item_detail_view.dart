import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'item_detail_controller.dart';

class ItemDetailView extends StatelessWidget {
  ItemDetailView({super.key});

  static const Color kPrimary = Color(0xFFFF5A00);
  static const Color kPrimaryDark = Color(0xFFE14D00);
  static const Color kPageBg = Color(0xFFF7F4EF);
  static const Color kCard = Colors.white;
  static const Color kText = Color(0xFF241A12);
  static const Color kMuted = Color(0xFF8B8B95);
  static const Color kBorder = Color(0xFFE9E3DA);

  final RxInt _fakeSize = 1.obs; // تصميم فقط: صغير/وسط/كبير

  @override
  Widget build(BuildContext context) {
    final c = Get.put(ItemDetailController());

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: kPageBg,
        body: Obx(() {
          final item = c.item;
          final fav = c.isFavorite.value;
          final avg = c.avgRating.value <= 0 ? item.rating : c.avgRating.value;

          return Stack(
            children: [
              CustomScrollView(
                physics: const BouncingScrollPhysics(),
                slivers: [
                  SliverToBoxAdapter(
                    child: Stack(
                      children: [
                        SizedBox(
                          height: 320,
                          width: double.infinity,
                          child: Image.network(
                            item.imageUrl,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                              color: const Color(0xFFEFE7DC),
                              alignment: Alignment.center,
                              child: const Icon(
                                Icons.fastfood_rounded,
                                size: 56,
                                color: kPrimary,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          top: MediaQuery.of(context).padding.top + 10,
                          left: 18,
                          child: _CircleTopButton(
                            icon: fav
                                ? Icons.favorite_rounded
                                : Icons.favorite_border_rounded,
                            color: fav ? Colors.red : kText,
                            onTap: c.toggleFavorite,
                          ),
                        ),
                        Positioned(
                          top: MediaQuery.of(context).padding.top + 10,
                          right: 18,
                          child: _CircleTopButton(
                            icon: Icons.arrow_forward_rounded,
                            color: kText,
                            onTap: Get.back,
                          ),
                        ),
                      ],
                    ),
                  ),

                  SliverToBoxAdapter(
                    child: Transform.translate(
                      offset: const Offset(0, -26),
                      child: Container(
                        decoration: const BoxDecoration(
                          color: kPageBg,
                          borderRadius: BorderRadius.vertical(
                            top: Radius.circular(28),
                          ),
                        ),
                        padding: const EdgeInsets.fromLTRB(18, 18, 18, 120),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '${item.price.toStringAsFixed(0)} ر.س',
                                  style: const TextStyle(
                                    color: kPrimary,
                                    fontSize: 18,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                                const Spacer(),
                                Expanded(
                                  flex: 3,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Text(
                                        item.name,
                                        textAlign: TextAlign.right,
                                        style: const TextStyle(
                                          color: kText,
                                          fontSize: 28 / 1.35,
                                          fontWeight: FontWeight.w900,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        item.name,
                                        textAlign: TextAlign.right,
                                        style: const TextStyle(
                                          color: kMuted,
                                          fontSize: 13,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),

                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 10,
                                    vertical: 5,
                                  ),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFF6EEE0),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Row(
                                    children: [
                                      const Icon(
                                        Icons.star_rounded,
                                        color: Color(0xFFF4B400),
                                        size: 16,
                                      ),
                                      const SizedBox(width: 4),
                                      Text(
                                        avg.toStringAsFixed(1),
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w800,
                                          color: kText,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Text(
                                  '(${c.comments.length} تقييم)',
                                  style: const TextStyle(
                                    color: kMuted,
                                    fontSize: 12.5,
                                  ),
                                ),
                                const Spacer(),
                              ],
                            ),

                            const SizedBox(height: 16),
                            Text(
                              item.description.isNotEmpty
                                  ? item.description
                                  : 'وصف غير متوفر حالياً',
                              textAlign: TextAlign.right,
                              style: const TextStyle(
                                color: kMuted,
                                fontSize: 14,
                                height: 1.65,
                              ),
                            ),

                            const SizedBox(height: 18),
                            const Text(
                              'اختر الحجم',
                              style: TextStyle(
                                color: kText,
                                fontSize: 15,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Obx(
                              () => Row(
                                children: [
                                  Expanded(
                                    child: _SizeChip(
                                      text: 'كبير',
                                      selected: _fakeSize.value == 2,
                                      onTap: () => _fakeSize.value = 2,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: _SizeChip(
                                      text: 'وسط',
                                      selected: _fakeSize.value == 1,
                                      onTap: () => _fakeSize.value = 1,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: _SizeChip(
                                      text: 'صغير',
                                      selected: _fakeSize.value == 0,
                                      onTap: () => _fakeSize.value = 0,
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            const SizedBox(height: 18),
                            const Text(
                              'الإضافات',
                              style: TextStyle(
                                color: kText,
                                fontSize: 15,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 10),

                            Obx(() {
                              final list = c.additions;
                              if (list.isEmpty) {
                                return const Text(
                                  'لا توجد إضافات لهذا الصنف',
                                  style: TextStyle(color: kMuted),
                                );
                              }

                              return Wrap(
                                spacing: 10,
                                runSpacing: 10,
                                children: List.generate(list.length, (i) {
                                  final a = list[i];
                                  return _AddonChip(
                                    title: a.name,
                                    price: a.price,
                                    selected: a.selected,
                                    onTap: () => c.toggleAddition(i),
                                  );
                                }),
                              );
                            }),

                            const SizedBox(height: 18),
                            const Text(
                              'إزالة مكوّنات',
                              style: TextStyle(
                                color: kText,
                                fontSize: 15,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 10),

                            Obx(() {
                              final list = c.removals;
                              if (list.isEmpty) {
                                return const Text(
                                  'لا توجد مكونات قابلة للإزالة',
                                  style: TextStyle(color: kMuted),
                                );
                              }

                              return Wrap(
                                spacing: 10,
                                runSpacing: 10,
                                children: List.generate(list.length, (i) {
                                  final r = list[i];
                                  return _RemovalChip(
                                    title: r.name,
                                    selected: r.selected,
                                    onTap: () => c.toggleRemoval(i),
                                  );
                                }),
                              );
                            }),

                            const SizedBox(height: 20),
                            const Text(
                              'تقييمك',
                              style: TextStyle(
                                color: kText,
                                fontSize: 15,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 10),

                            Obx(
                              () => Row(
                                children: List.generate(5, (i) {
                                  final star = i + 1;
                                  final selected =
                                      c.selectedStars.value >= star;
                                  return IconButton(
                                    onPressed: () =>
                                        c.selectedStars.value = star,
                                    icon: Icon(
                                      selected
                                          ? Icons.star_rounded
                                          : Icons.star_border_rounded,
                                      color: const Color(0xFFF4B400),
                                    ),
                                  );
                                }),
                              ),
                            ),

                            const SizedBox(height: 8),
                            _CommentBox(
                              hint: 'اكتب تعليقك...',
                              onSend: (text) => c.submitComment(text),
                              busy: c.commentBusy,
                            ),

                            const SizedBox(height: 20),
                            const Text(
                              'تعليقات الزبائن',
                              style: TextStyle(
                                color: kText,
                                fontSize: 15,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 10),

                            Obx(() {
                              if (c.loadingComments.value) {
                                return const Center(
                                  child: CircularProgressIndicator(
                                    color: kPrimary,
                                  ),
                                );
                              }

                              if (c.comments.isEmpty) {
                                return const Text(
                                  'لا توجد تعليقات بعد',
                                  style: TextStyle(color: kMuted),
                                );
                              }

                              return Column(
                                children: c.comments.map((cm) {
                                  return Container(
                                    margin: const EdgeInsets.only(bottom: 10),
                                    padding: const EdgeInsets.all(12),
                                    decoration: BoxDecoration(
                                      color: kCard,
                                      borderRadius: BorderRadius.circular(16),
                                      border: Border.all(color: kBorder),
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      children: [
                                        Text(
                                          cm.userName,
                                          style: const TextStyle(
                                            fontWeight: FontWeight.w800,
                                            color: kText,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          cm.comment,
                                          textAlign: TextAlign.right,
                                          style: const TextStyle(
                                            color: kMuted,
                                            height: 1.5,
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                }).toList(),
                              );
                            }),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),

              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: SafeArea(
                  top: false,
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(18, 12, 18, 14),
                    decoration: BoxDecoration(
                      color: kCard,
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(24),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(.08),
                          blurRadius: 18,
                          offset: const Offset(0, -6),
                        ),
                      ],
                    ),
                    child: Obx(() {
                      return Row(
                        children: [
                          Expanded(
                            child: ElevatedButton(
                              onPressed: c.isAdding.value
                                  ? null
                                  : () async {
                                      await c.addToCart();
                                      if (c.lastAddSuccess.value) {
                                        Get.snackbar(
                                          'تم',
                                          'تمت إضافة الصنف إلى السلة',
                                          snackPosition: SnackPosition.BOTTOM,
                                        );
                                      }
                                    },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: kPrimary,
                                disabledBackgroundColor: Colors.grey.shade400,
                                padding: const EdgeInsets.symmetric(
                                  vertical: 15,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(16),
                                ),
                              ),
                              child: c.isAdding.value
                                  ? const SizedBox(
                                      width: 18,
                                      height: 18,
                                      child: CircularProgressIndicator(
                                        color: Colors.white,
                                        strokeWidth: 2,
                                      ),
                                    )
                                  : Text(
                                      'أضف إلى السلة • ${c.total.toStringAsFixed(0)} ر.س',
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                            ),
                          ),
                          const SizedBox(width: 14),
                          _QtyButton(
                            icon: Icons.remove_rounded,
                            bg: const Color(0xFFF1F1F4),
                            fg: Colors.black54,
                            onTap: c.decQty,
                          ),
                          const SizedBox(width: 12),
                          Obx(
                            () => Text(
                              '${c.qty.value}',
                              style: const TextStyle(
                                color: kText,
                                fontWeight: FontWeight.w900,
                                fontSize: 18,
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          _QtyButton(
                            icon: Icons.add_rounded,
                            bg: kPrimary,
                            fg: Colors.white,
                            onTap: c.incQty,
                          ),
                        ],
                      );
                    }),
                  ),
                ),
              ),
            ],
          );
        }),
      ),
    );
  }
}

class _CircleTopButton extends StatelessWidget {
  const _CircleTopButton({
    required this.icon,
    required this.color,
    required this.onTap,
  });

  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withOpacity(.92),
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 44,
          height: 44,
          child: Icon(icon, color: color, size: 22),
        ),
      ),
    );
  }
}

class _SizeChip extends StatelessWidget {
  const _SizeChip({
    required this.text,
    required this.selected,
    required this.onTap,
  });

  final String text;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: Container(
        height: 42,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFFFF2EA) : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? ItemDetailView.kPrimary : ItemDetailView.kBorder,
          ),
        ),
        child: Text(
          text,
          style: TextStyle(
            color: selected ? ItemDetailView.kPrimary : ItemDetailView.kText,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    );
  }
}

class _AddonChip extends StatelessWidget {
  const _AddonChip({
    required this.title,
    required this.price,
    required this.selected,
    required this.onTap,
  });

  final String title;
  final double price;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: Container(
        width: 148,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFFFF2EA) : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? ItemDetailView.kPrimary : ItemDetailView.kBorder,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.right,
              style: const TextStyle(
                color: ItemDetailView.kText,
                fontWeight: FontWeight.w700,
                height: 1.3,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              '+${price.toStringAsFixed(0)} ر.س',
              style: const TextStyle(
                color: ItemDetailView.kPrimary,
                fontWeight: FontWeight.w800,
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RemovalChip extends StatelessWidget {
  const _RemovalChip({
    required this.title,
    required this.selected,
    required this.onTap,
  });

  final String title;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: Container(
        width: 148,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFFFF2EA) : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? ItemDetailView.kPrimary : ItemDetailView.kBorder,
          ),
        ),
        child: Text(
          title,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          textAlign: TextAlign.right,
          style: const TextStyle(
            color: ItemDetailView.kText,
            fontWeight: FontWeight.w700,
            height: 1.3,
          ),
        ),
      ),
    );
  }
}

class _QtyButton extends StatelessWidget {
  const _QtyButton({
    required this.icon,
    required this.bg,
    required this.fg,
    required this.onTap,
  });

  final IconData icon;
  final Color bg;
  final Color fg;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(icon, color: fg),
      ),
    );
  }
}

class _CommentBox extends StatefulWidget {
  const _CommentBox({
    required this.hint,
    required this.onSend,
    required this.busy,
  });

  final String hint;
  final Future<void> Function(String text) onSend;
  final RxBool busy;

  @override
  State<_CommentBox> createState() => _CommentBoxState();
}

class _CommentBoxState extends State<_CommentBox> {
  final _ctrl = TextEditingController();

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: ItemDetailView.kBorder),
      ),
      child: Row(
        children: [
          Obx(
            () => IconButton(
              onPressed: widget.busy.value
                  ? null
                  : () async {
                      final text = _ctrl.text.trim();
                      await widget.onSend(text);
                      if (mounted) _ctrl.clear();
                    },
              icon: widget.busy.value
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(
                      Icons.send_rounded,
                      color: ItemDetailView.kPrimary,
                    ),
            ),
          ),
          Expanded(
            child: TextField(
              controller: _ctrl,
              textAlign: TextAlign.right,
              decoration: InputDecoration(
                hintText: widget.hint,
                border: InputBorder.none,
                hintStyle: const TextStyle(color: ItemDetailView.kMuted),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
